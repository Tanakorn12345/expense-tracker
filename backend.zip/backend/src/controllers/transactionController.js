const transactionService = require('../services/transactionService');
const prisma = require('../db/prisma');

const transactionController = {
  getTransactions: async (req, res, next) => {
    try {
      const transactions = await transactionService.getTransactions(req.query);
      res.json(transactions);
    } catch (error) {
      next(error);
    }
  },

  getStats: async (req, res, next) => {
    try {
      const stats = await transactionService.getStats();
      res.json(stats);
    } catch (error) {
      next(error);
    }
  },

  createTransaction: async (req, res, next) => {
    try {
      const newTransaction = await transactionService.createTransaction(req.body);
      res.status(201).json(newTransaction);
    } catch (error) {
      res.status(400); // Bad Request
      next(error);
    }
  },

  getCategories: async (req, res, next) => {
    try {
      const categories = await prisma.category.findMany();
      const expense = categories.filter(c => c.type === 'expense').map(c => c.name);
      const income = categories.filter(c => c.type === 'income').map(c => c.name);
      res.json({ expense, income });
    } catch (error) {
      next(error);
    }
  }
};

module.exports = transactionController;
