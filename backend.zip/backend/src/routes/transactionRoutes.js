const express = require('express');
const router = express.Router();
const transactionController = require('../controllers/transactionController');

// Get all transactions
router.get('/', transactionController.getTransactions);

// Get stats
router.get('/stats', transactionController.getStats);

// Create transaction
router.post('/', transactionController.createTransaction);

// Get categories
router.get('/categories', transactionController.getCategories);

module.exports = router;
