const transactionRepository = require('../repositories/transactionRepository');
const prisma = require('../db/prisma');

const transactionService = {
  async getTransactions(filters) {
    let where = { userId: 1 }; // Mock User ID
    
    if (filters.search) {
      where.OR = [
        { title: { contains: filters.search, mode: 'insensitive' } },
        { subtitle: { contains: filters.search, mode: 'insensitive' } },
        { category: { name: { contains: filters.search, mode: 'insensitive' } } }
      ];
    }
    
    if (filters.categoryId) where.categoryId = parseInt(filters.categoryId);
    if (filters.type) where.category = { type: filters.type };

    return await transactionRepository.findAll(where);
  },

  async createTransaction(data) {
    const category = await prisma.category.findFirst({
      where: { name: data.categoryName }
    });

    if (!category) throw new Error("Category not found");

    return await transactionRepository.create({
      title: data.title,
      subtitle: data.subtitle || category.name,
      amount: parseFloat(data.amount),
      date: data.date ? new Date(data.date) : new Date(),
      userId: 1, // Mock User ID
      categoryId: category.id
    });
  },

  async getStats() {
    const transactions = await transactionRepository.findAll({ userId: 1 });
    
    const totalIncome = transactions
      .filter(t => t.category.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
    
    const totalExpenses = transactions
      .filter(t => t.category.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);

    return {
      totalBalance: 124592.00 + (totalIncome - totalExpenses),
      monthlyIncome: totalIncome,
      monthlyExpenses: totalExpenses,
      incomeTargetReached: Math.min(Math.round((totalIncome / 15000) * 100), 100),
      expenseBudgetStatus: Math.round(((totalExpenses - 5000) / 5000) * 100)
    };
  }
};

module.exports = transactionService;
