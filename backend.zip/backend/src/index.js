const express = require('express');
const cors = require('cors');
require('dotenv').config();

const transactionRoutes = require('./routes/transactionRoutes');

const app = express();
const PORT = process.env.PORT || 5001;

app.use(cors());
app.use(express.json());

// Routes
app.use('/api/transactions', transactionRoutes);

// Shared APIs (like forecast)
app.get('/api/forecast', (req, res) => {
  res.json({
    predictedIncome: 13200,
    predictedExpenses: 4150,
    netSavings: 9050,
    efficiency: 8.5,
    insights: [
      { id: 1, type: 'saving', title: "Cut Subscriptions", text: "You have 3 unused streaming services." },
      { id: 2, type: 'investment', title: "Invest Surplus", text: "Your cash reserve is $2k above target." }
    ]
  });
});

// Global Error Handler Middleware
app.use((err, req, res, next) => {
  const statusCode = res.statusCode !== 200 ? res.statusCode : 500;
  res.status(statusCode).json({
    message: err.message || 'Internal Server Error',
    stack: process.env.NODE_ENV === 'production' ? '🥞' : err.stack,
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
